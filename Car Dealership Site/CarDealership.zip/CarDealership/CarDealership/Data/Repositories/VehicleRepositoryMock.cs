﻿using CarDealership.UI.Models;
using CarDealership.UI.Models.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CarDealership.UI.Data.Repositories
{
    public class VehicleRepositoryMock : IVehicleRepository
    {
        //SEVERAL repositories

        private static List<Vehicle> list = new List<Vehicle>
        {
            new Vehicle {BodyStyleId = 0, ColorId = 0, DateCreated = new DateTime(1/1/16), Description = "A cool vehicle.", InteriorId = 0,
                         Mileage = "30000 Miles", ModelId = 0, MSRP = 45000.00m, Price = 14999.99m, Transmission = "Automatic", Type = "Used",
                         UserId = "A", VehicleId = 0, VIN = "1a1a1a1a1a1a1a1a1", Picture = "/Pictures/BlackTruck.jpg", Featured = 1},
            new Vehicle {BodyStyleId = 1, ColorId = 1, DateCreated = new DateTime(2/2/13), Description = "An alright SUV.", InteriorId = 1,
                         Mileage = "50000 Miles", ModelId = 1, MSRP = 55000.00m, Price = 25000, Transmission = "Manual", Type = "Used",
                         UserId = "B", VehicleId = 1, VIN = "2b2b2b2b2b2b2b2b2", Picture = "/Pictures/RedSUV.jpg", Featured = 0},
            new Vehicle {BodyStyleId = 2, ColorId = 2, DateCreated = new DateTime(3/3/20), Description = "A bad car.", InteriorId = 2,
                         Mileage = "5 Miles", ModelId = 2, MSRP = 77777.77m, Price = 44444.44m, Transmission = "Automatic", Type = "New",
                         UserId = "C", VehicleId = 2, VIN = "3c3c3c3c3c3c3c3c3", Picture = "/Pictures/YellowSedan.png", Featured = 1}
        };

        public List<Vehicle> Create(Vehicle vehicle)
        {
            vehicle.VehicleId = list.Max(c => c.VehicleId) + 1;
            vehicle.DateCreated = DateTime.Today;
            list.Add(vehicle);
            return list;
        }

        public List<Vehicle> Delete(int id)
        {
            Vehicle vehicle = new Vehicle();
            foreach (var item in list)
            {
                if (item.VehicleId == id)
                {
                    vehicle = item;
                    list.Remove(vehicle);
                    break;
                }
            }
            return list;
        }

        public List<Vehicle> RetrieveAll()
        {
            return list;
        }

        public List<Vehicle> NewSearch(string searchBar, decimal? minPrice, decimal? maxPrice, int? minYear, int? maxYear)
        {
            List<Vehicle> newList = Search(searchBar, minPrice, maxPrice, minYear, maxYear);

            foreach (var item in newList)
            {
                if (item.Type.ToUpper() != "NEW")
                {
                    newList.Remove(item);
                }
            }

            return newList;
        }

        public List<Vehicle> Update(Vehicle vehicle)
        {
            foreach (var item in list)
            {
                if (item.VehicleId == vehicle.VehicleId)
                {
                    list.Remove(item);
                    list.Add(vehicle);
                    break;
                }
            }

            return list;
        }

        public List<Vehicle> UsedSearch(string searchBar, decimal? minPrice, decimal? maxPrice, int? minYear, int? maxYear)
        {
            List<Vehicle> newList = Search(searchBar, minPrice, maxPrice, minYear, maxYear);

            foreach (var item in newList)
            {
                if (item.Type.ToUpper() != "USED")
                {
                    newList.Remove(item);
                }
            }

            return newList;
        }

        public Vehicle RetrieveOne(int id)
        {
            Vehicle vehicle = new Vehicle();
            foreach (var item in list)
            {
                if (item.VehicleId == id)
                {
                    vehicle = item;
                }
            }
            return vehicle;
        }

        public List<Vehicle> Search(string searchBar, decimal? minPrice, decimal? maxPrice, int? minYear, int? maxYear)
        {
            List<Vehicle> newList = list;

            RepoFactory repo = new RepoFactory();

            //Searchbar
            if (searchBar != "")
            {
                newList.Clear();
                //Get matching makes & models, exclude duplicates
                foreach (var model in repo.ModelFactory().RetrieveAll())
                {
                    if (model.ModelName.Contains(searchBar))
                    {
                        newList = list.Where(x => x.ModelId == model.ModelId).ToList();
                    }
                }

                foreach (var make in repo.MakeFactory().RetrieveAll())
                {
                    foreach (var model in repo.ModelFactory().RetrieveAll())
                    {
                        foreach (var entry in newList)
                        {
                            if (make.MakeName.Contains(searchBar) && make.MakeId == model.MakeId && !(newList.Contains(entry)))
                            {
                                newList.Add(entry);
                            }
                        }
                    }
                }

                //Get matching year, exclude duplicates
                foreach (var model in repo.ModelFactory().RetrieveAll())
                {
                    foreach (var entry in newList)
                    {
                        if (model.ModelYear.ToString().Contains(searchBar) && !(newList.Contains(entry)))
                        {
                            newList = list.Where(x => x.ModelId == model.ModelId).ToList();
                        }
                    }
                }
            }

            //Make sure that elements are removed if they dont fit parameters (single foreach?)

            //Minimum price
            if (minPrice != null)
            {
                foreach (var item in newList.Where(x => x.Price < minPrice).ToList())
                {
                    newList.Remove(item);
                }
            }

            //Maximum price
            if (maxPrice != null)
            {
                foreach (var item in newList.Where(x => x.Price > minPrice).ToList())
                {
                    newList.Remove(item);
                }
            }

            //Minimum year
            if (minYear != null)
            {
                foreach (var model in repo.ModelFactory().RetrieveAll())
                {
                    foreach (var entry in newList)
                    {
                        if (model.ModelYear < minYear && entry.ModelId == model.ModelId)
                        {
                            newList.Remove(entry);
                        }
                    }
                }
            }

            //Maximum year
            if (maxYear != null)
            {
                foreach (var model in repo.ModelFactory().RetrieveAll())
                {
                    foreach (var entry in newList)
                    {
                        if (model.ModelYear > minYear && entry.ModelId == model.ModelId)
                        {
                            newList.Remove(entry);
                        }
                    }
                }
            }
            if (searchBar == "" && minPrice == null && maxPrice == null && minYear == null && maxYear == null)
            {
                newList.OrderByDescending(x => x.MSRP);
            }

            return newList;
        }
    }
}