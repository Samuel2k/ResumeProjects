﻿using CarDealership.UI.Models.Classes;
using CarDealership.UI.Models.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CarDealership.UI.Data.Repositories
{
    public class PurchaseRepositoryMock : IPurchaseRepository
    {
        private static List<Purchase> list = new List<Purchase>
        {
            new Purchase { City = "Cheeseland", DateCreated = new DateTime(1/1/20), Email = "Example@Example.com", Name = "Michael Shoe",
            PhoneNumber = "111-222-3333", PurchaseId = 0, PurchasePrice = 14999.99m, State = "XA", Street1 = "123 Soap Avenue", Street2 = "",
            VehicleId = 0, ZipCode = "55555"},
            new Purchase { City = "Rollerville", DateCreated = new DateTime(2/2/20), Email = "Sample@Sample.net", Name = "Iron Man",
            PhoneNumber = "222-333-4444", PurchaseId = 1, PurchasePrice = 24999.99m, State = "ZA", Street1 = "14 Shampoo Boulevard", Street2 = "",
            VehicleId = 1, ZipCode = "44444"},
            new Purchase { City = "Death Valley", DateCreated = new DateTime(3/3/16), Email = "What@What.what", Name = "Huhman Whatson",
            PhoneNumber = "333-444-5555", PurchaseId = 2, PurchasePrice = 44444, State = "WW", Street1 = "3452 Nope Street", Street2 = "Apartment 91",
            VehicleId = 2, ZipCode = "98765"}
        };

        public List<Purchase> Create(Purchase purchase)
        {
            purchase.PurchaseId = list.Max(c => c.PurchaseId) + 1;
            purchase.DateCreated = DateTime.Today;
            list.Add(purchase);
            return list;
        }

        public List<Purchase> RetrieveAll()
        {
            return list;
        }
    }
}