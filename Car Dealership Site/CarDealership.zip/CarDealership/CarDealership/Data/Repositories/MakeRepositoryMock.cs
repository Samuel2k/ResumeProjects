﻿using CarDealership.UI.Models.Classes;
using CarDealership.UI.Models.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CarDealership.UI.Data.Repositories
{
    public class MakeRepositoryMock :IMakeRepository
    {
        private static List<Make> list = new List<Make>
        {
            new Make { DateCreated = new DateTime(1/1/20), MakeId = 0, MakeName = "VehicleLand", UserId = "A"},
            new Make { DateCreated = new DateTime(2/2/19), MakeId = 1, MakeName = "John's cars", UserId = "B"},
            new Make { DateCreated = new DateTime(3/3/18), MakeId = 2, MakeName = "Super Motors", UserId = "C"}
        };

        public List<Make> Create(Make make)
        {
            make.MakeId = list.Max(c => c.MakeId) + 1;
            make.DateCreated = DateTime.Today;
            list.Add(make);
            return list;
        }

        public List<Make> RetrieveAll()
        {
            return list;
        }

        public Make RetrieveOne(int id)
        {
            Make make = new Make();
            foreach (var item in list)
            {
                if (item.MakeId == id)
                {
                    make = item;
                    break;
                }
            }
            return make;
        }
    }
}