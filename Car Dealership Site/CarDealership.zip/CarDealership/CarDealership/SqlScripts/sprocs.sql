USE GuildCars
GO

/*Contacts*/
CREATE PROCEDURE RetrieveAllContacts
AS
SELECT *
FROM Contacts
GO

CREATE PROCEDURE CreateContact(@ContactId INT,
							   @Email NVARCHAR(40),
							   @Name NVARCHAR(60),
							   @Message NVARCHAR(500),
							   @Phone NVARCHAR(15))
AS
	INSERT INTO [Contacts] (ContactId, Email, Name, Message, Phone)
	VALUES (@ContactId, @Email, @Name, @Message, @Phone)
GO

/*Vehicles*/
CREATE PROCEDURE RetrieveAllVehicles
AS
	SELECT *
	FROM Vehicles
GO

CREATE PROCEDURE CreateVehicle (@Type NVARCHAR(4),
								@Transmission NVARCHAR(15),
								@Mileage NVARCHAR(20),
								@VIN VARCHAR(17),
								@MSRP DECIMAL,
								@Price DECIMAL,
								@Description NVARCHAR(250),
								@DateCreated NVARCHAR(10),
								@Picture NVARCHAR(250),
								@Featured BIT,

								@ModelId INT,
								@BodyStyleId INT,
								@ColorId INT,
								@InteriorId INT,
								@UserId NVARCHAR(128))
AS
	INSERT INTO [Vehicles] (Type, Transmission, Mileage, VIN, MSRP, Price, Description, DateCreated, Picture, Featured, ModelId, BodyStyleId, ColorId, InteriorId, UserId)
	VALUES (@Type, @Transmission, @Mileage, @VIN, @MSRP, @Price, @Description, @DateCreated, @Picture, @Featured, @ModelId, @BodyStyleId, @ColorId, @InteriorId, @UserId)
GO

CREATE PROCEDURE DeleteVehicle (@VehicleId INT)
AS
	DELETE FROM [Vehicles] WHERE VehicleId = @VehicleId
GO

CREATE PROCEDURE UpdateVehicle (@VehicleId INT,
								@Type NVARCHAR(4),
								@Transmission NVARCHAR(15),
								@Mileage NVARCHAR(20),
								@VIN VARCHAR(17),
								@MSRP DECIMAL,
								@Price DECIMAL,
								@Description NVARCHAR(250),
								@DateCreated NVARCHAR(10),
								@Picture NVARCHAR(250),
								@Featured BIT,

								@ModelId INT,
								@BodyStyleId INT,
								@ColorId INT,
								@InteriorId INT,
								@UserId NVARCHAR(128))
AS
	UPDATE [Vehicles] 
	SET Type = @Type, 
		Transmission = @Transmission, 
		Mileage = @Mileage,
		VIN = @VIN,
		MSRP = @MSRP,
		Price = @Price,
		Description = @Description, 
		DateCreated = @DateCreated,
		Picture = @Picture,
		Featured = @Featured,
		ModelId = @ModelId,
		BodyStyleId = @BodyStyleId,
		ColorId = @ColorId,
		InteriorId = @InteriorId,
		UserId = @UserId
	WHERE VehicleId = @VehicleId 
GO

/*Purchases*/
CREATE PROCEDURE RetrieveAllPurchases
AS
	SELECT *
	FROM Purchases
GO

CREATE PROCEDURE CreatePurchase (@PurchaseId INT,
								 @VehicleId INT,
								 @PurchasePrice DECIMAL,
								 @PurchaseType NVARCHAR(15),
								 @Name NVARCHAR(60),
								 @PhoneNumber NVARCHAR(15),
								 @Email NVARCHAR(40),
								 @Street1 NVARCHAR(30),
								 @Street2 NVARCHAR(30),
								 @City NVARCHAR(50),
								 @ZipCode NVARCHAR (5),
								 @StateAbbreviation VARCHAR(2),
								 @DateCreated NVARCHAR(10))
AS
	INSERT INTO [Purchases] (PurchaseId, VehicleId, PurchasePrice, PurchaseType, Name, PhoneNumber, Email, Street1, Street2, City, ZipCode, StateAbbreviation, DateCreated)
	VALUES (@PurchaseId, @VehicleId, @PurchasePrice, @PurchaseType, @Name, @PhoneNumber, @Email, @Street1, @Street2, @City, @ZipCode, @StateAbbreviation, @DateCreated)
GO

/*Model*/
CREATE PROCEDURE RetrieveAllModels
AS
	SELECT *
	FROM Models
GO

CREATE PROCEDURE CreateModel (@ModelId INT,
							  @ModelName NVARCHAR(55),
							  @ModelYear NVARCHAR(4),
							  @DateCreated DATE,
							  @MakeId INT,
							  @UserId NVARCHAR(128))
AS
	INSERT INTO [Models] (ModelId, ModelName, ModelYear, DateCreated, MakeId, UserId)
	VALUES (@ModelId, @ModelName, @ModelYear, @DateCreated, @MakeId, @UserId)
GO

/*Make*/
CREATE PROCEDURE RetrieveAllMakes
AS
	SELECT *
	FROM Makes
GO

CREATE PROCEDURE CreateMake (@MakeId INT,
							 @MakeName NVARCHAR(20),
							 @DateCreated DATE,
							 @UserId NVARCHAR(128))
AS
	INSERT INTO [Makes] (MakeId, MakeName, DateCreated, UserId)
	VALUES (@MakeId, @MakeName, @DateCreated, @UserId)
GO

/*Specials*/
CREATE PROCEDURE CreateSpecial (@SpecialId INT,
							 @SpecialTitle NVARCHAR(30),
							 @SpecialDescription NVARCHAR(500))
AS
INSERT INTO [Specials] (SpecialId, SpecialTitle, SpecialDescription)
	VALUES (@SpecialId, @SpecialTitle, @SpecialDescription)
GO

CREATE PROCEDURE RetrieveAllSpecials
AS
	SELECT *
	FROM Specials
GO

/*BodyStyle, Color, Interior*/
CREATE PROCEDURE RetrieveAllBodyStyles
AS
	SELECT *
	FROM BodyStyles
GO

CREATE PROCEDURE RetrieveAllColors
AS
	SELECT *
	FROM Colors
GO

CREATE PROCEDURE RetrieveAllInteriors
AS
	SELECT *
	FROM Interiors
GO