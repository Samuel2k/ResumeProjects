USE GuildCars
GO

SET IDENTITY_INSERT Specials ON

INSERT INTO Specials (SpecialId, SpecialTitle, SpecialDescription) VALUES
(0, 'BIG MONEY, BIG PRIZES', 'I LLLOVE IT!'),
(1, 'Save a dollar', 'Save a dollar on stuff today.'),
(2, 'John Shoemaker Charity', 'Help us raise money for the John Shoemaker childrens cobbler fund! 5% of each purchase goes to making a child in need a shoe.')

SET IDENTITY_INSERT Specials OFF

/*Insert into user as well*/
INSERT INTO AspNetUsers (Id, EmailConfirmed, PhoneNumberConfirmed, TwoFactorEnabled, LockoutEnabled, AccessFailedCount, UserName) VALUES
('A1', 0, 0, 0, 0, 0, 'John Legman'),
('B2', 0, 0, 0, 0, 0, 'Fred ShoeMaker'),
('C3', 0, 0, 0, 0, 0, 'Fred Newman'),
('D4', 0, 0, 0, 0, 0, 'Canister Johnson')

INSERT INTO AspNetRoles (Id, Name) VALUES
('A', 'Sales'),
('B', 'Admin')

INSERT INTO AspNetUserRoles (UserId, RoleId) VALUES
('A1', 'A'),
('B2', 'B'),
('C3', 'C'),
('D4', 'D')

SET IDENTITY_INSERT Makes ON

INSERT INTO Makes (MakeId, MakeName, DateCreated, UserId) VALUES
(0, 'Spaghetti', '10/12/12', 'A1'),
(1, 'Rockefeller', '3/3/03', 'B2'),
(2, 'MaidenIron', '4/4/04', 'C3')

SET IDENTITY_INSERT Makes OFF

SET IDENTITY_INSERT Models ON

INSERT INTO Models (ModelId, ModelName, ModelYear, DateCreated, MakeId, UserId) VALUES
(0, 'X9', '2010', '1/2/03', 0, 'A1'),
(1, 'EE', '2006', '2/3/04', 1, 'B2'),
(2, 'SQ', '2019', '3/4/05', 2, 'C3')

SET IDENTITY_INSERT Models OFF

SET IDENTITY_INSERT Colors ON

INSERT INTO Colors (ColorId, ColorName) VALUES
(0, 'Purple'),
(1, 'Green'),
(2, 'Blue'),
(3, 'Aqua'),
(4, 'Navy')

SET IDENTITY_INSERT Colors OFF

SET IDENTITY_INSERT BodyStyles ON

INSERT INTO BodyStyles (BodyStyleId, BodyStyleName) VALUES
(0, 'Truck'),
(1, 'Car'),
(2, 'SUV'),
(2, 'Van')

SET IDENTITY_INSERT BodyStyles OFF

SET IDENTITY_INSERT Interiors ON

INSERT INTO Interiors (InteriorId, InteriorName) VALUES
(0, 'Red Leather'),
(1, 'Periwinkle w/ Steel Roll Cage'),
(2, 'Carpeted Ceiling')

SET IDENTITY_INSERT Interiors OFF

SET IDENTITY_INSERT Vehicles ON

INSERT INTO Vehicles (VehicleId, Type, Transmission, Mileage, VIN, MSRP, Price, Description, DateCreated, Picture, ModelId, BodyStyleId, ColorId, InteriorId, UserId, Featured) VALUES
(0, 'Used', 'Automatic', '2500 Miles', '1a1a1a1a1a1a1a1a1', 35000, 30000, 'A car. Its pretty cool. Please buy it.', '1/1/11', '.../Pictures/BlackTruck.jpg', 0, 0, 0, 0, 'A1', 0),
(1, 'New', 'Automatic', '2 Miles', '2b2b2b2b2b2b2b2b2', 44000, 34000, 'A car. Haha.', '2/2/12', '.../Pictures/RedSUV.jpg', 1, 1, 1, 1, 'B2', 0),
(2, 'Used', 'Automatic', '212,600 Miles', '3c3c3c3c3c3c3c3c3', 13000, 1000, 'Is this even used?',' 3/3/13', '.../Pictures/YellowSedan.png', 2, 2, 2, 2, 'C3', 0)

SET IDENTITY_INSERT Vehicles OFF

SET IDENTITY_INSERT Purchases ON

INSERT INTO Purchases (PurchaseId, VehicleId, PurchasePrice, PurchaseType, Name, PhoneNumber, Email, Street1, Street2, City, ZipCode, StateAbbreviation, DateCreated) VALUES
(0, 0, 30000, 'Dealer Finance', 'Fredrick Johnson', '999-888-7777', 'FredJ@place.place', 'Shoemaker Ave', '', 'Woodcity', '12345', 'XX', '1/1/01'), 
(1, 1, 56000, 'Out-of-pocket', 'Mary Kneeble', '676-123-2345', 'Steamguy@ice.site', 'Bad cheese Bld', 'Apartment 3', 'Iron ville', '98545', 'AC', '3/2/06')

SET IDENTITY_INSERT Purchases OFF