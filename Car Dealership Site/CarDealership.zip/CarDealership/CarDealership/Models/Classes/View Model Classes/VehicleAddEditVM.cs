﻿using CarDealership.UI.Models.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CarDealership.Models.Classes.View_Model_Classes
{
    public class VehicleAddEditVM
    {
        public Vehicle Vehicle { get; set; }
        public Color Color { get; set; }
        public Make Make { get; set; }
        public Model Model { get; set; }
        public BodyStyle BodyStyle { get; set; }
        public Interior Interior { get; set; }

        public List<Color> ColorList { get; set; }
        public List<Make> MakeList { get; set; }
        public List<Model> ModelList { get; set; }
        public List<BodyStyle> BodyStyleList { get; set; }
        public List<Interior> InteriorList { get; set; }
    }
}