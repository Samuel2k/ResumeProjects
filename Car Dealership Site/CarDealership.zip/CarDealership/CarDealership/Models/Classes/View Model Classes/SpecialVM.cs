﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CarDealership.Models.Classes.View_Model_Classes
{
    public class SpecialVM
    {
        public Special Special { get; set; }
        public List<Special> SpecialList { get; set; }
    }
}