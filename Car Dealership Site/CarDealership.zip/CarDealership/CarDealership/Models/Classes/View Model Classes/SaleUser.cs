﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CarDealership.Models.Classes.View_Model_Classes
{
    public class SaleUser
    {
        public string UserId { get; set; }
        
    }
}