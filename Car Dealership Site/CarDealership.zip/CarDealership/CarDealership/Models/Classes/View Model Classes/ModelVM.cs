﻿using CarDealership.UI.Models.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CarDealership.Models.Classes.View_Model_Classes
{
    public class ModelVM
    {
        public Model Model {get; set;}
        public List<MakeModel> MakeModelList { get; set; }
        public List<Make> MakeList { get; set; }
    }
}