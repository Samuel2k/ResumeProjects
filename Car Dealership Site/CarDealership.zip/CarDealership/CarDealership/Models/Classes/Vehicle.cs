﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace CarDealership.UI.Models.Classes
{
    //Make the tables equivalent to the SQL side
    public class Vehicle
    {
        public int VehicleId { get; set; }

        [Required]
        public string Type { get; set; }

        [Required]
        public string Transmission { get; set; }

        [Required]
        public string Mileage { get; set; }

        [Required]
        public string VIN { get; set; }

        [Required]
        public decimal MSRP { get; set; }

        [Required]
        public decimal Price { get; set; }

        [Required]
        public string Description { get; set; }
        public DateTime DateCreated { get; set; }

        [Required]
        public int ModelId { get; set; }

        [Required]
        public int BodyStyleId { get; set; }

        [Required]
        public int ColorId { get; set; }

        [Required]
        public int InteriorId { get; set; }

        [Required]
        public string UserId { get; set; }

        [Required]
        public string Picture { get; set; }

        [Required]
        public byte Featured { get; set; }
    }
}