﻿using CarDealership.Models.Classes;
using CarDealership.Models.Classes.View_Model_Classes;
using CarDealership.UI.Data;
using CarDealership.UI.Models.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace CarDealership.Controllers
{
    public class SalesController : Controller
    {
        //Done?
        [HttpGet]
        public ActionResult Purchase(int id)
        {
            PurchaseVM purchaseVM = new PurchaseVM
            {
                Purchase = new Purchase(),
                VehicleVM = new VehicleVM()
            };     
            purchaseVM.SetFinanceItems(new List<string> { "Bank Finance", "Cash", "Dealer Finance" });
            purchaseVM.SetStateItems(new List<string> { "MN", "AZ", "LA" });
            return View(purchaseVM);
        }

        [HttpPost]
        public ActionResult Purchase(PurchaseVM purchaseVM)
        {
            purchaseVM.Purchase.DateCreated = DateTime.Today;
            new RepoFactory().PurchaseFactory().Create(purchaseVM.Purchase);

            return RedirectToAction("Vehicles");
        }

        [HttpGet]
        public ActionResult Vehicles()
        {
            return View();
        }
    }
}