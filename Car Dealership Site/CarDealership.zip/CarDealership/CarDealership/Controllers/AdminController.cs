﻿using CarDealership.Models.Classes;
using CarDealership.Models.Classes.View_Model_Classes;
using CarDealership.UI.Data;
using CarDealership.UI.Models.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace CarDealership.Controllers
{
    public class AdminController : Controller
    {
        //Need Users and EditUser

        private static RepoFactory repo = new RepoFactory();

        public ActionResult Vehicles()
        {
            return View();
        }

        [HttpGet]
        public ActionResult AddVehicle()
        {
            VehicleAddEditVM VM = new VehicleAddEditVM
            {
                BodyStyleList = repo.BodyStyleFactory().RetrieveAll(),
                ColorList = repo.ColorFactory().RetrieveAll(),
                InteriorList = repo.InteriorFactory().RetrieveAll(),
                MakeList = repo.MakeFactory().RetrieveAll(),
                ModelList = repo.ModelFactory().RetrieveAll()
            };
            return View(VM);
        }

        [HttpPost]
        public ActionResult AddVehicle(VehicleAddEditVM vehicleAddEditVM)
        {
            vehicleAddEditVM.Vehicle.DateCreated = DateTime.Today;
            repo.VehicleFactory().Create(vehicleAddEditVM.Vehicle);
            return RedirectToAction("Vehicles");
        }

        [HttpGet]
        public ActionResult EditVehicle(int id)
        {
            VehicleAddEditVM VM = new VehicleAddEditVM
            {
                Vehicle = repo.VehicleFactory().RetrieveOne(id),

                BodyStyleList = repo.BodyStyleFactory().RetrieveAll(),
                ColorList = repo.ColorFactory().RetrieveAll(),
                InteriorList = repo.InteriorFactory().RetrieveAll(),
                MakeList = repo.MakeFactory().RetrieveAll(),
                ModelList = repo.ModelFactory().RetrieveAll()
            };
            return View(VM);
        }

        [HttpPost]
        public ActionResult EditVehicle(VehicleAddEditVM vehicleAddEditVM)
        {
            vehicleAddEditVM.Vehicle.DateCreated = DateTime.Today;
            repo.VehicleFactory().Update(vehicleAddEditVM.Vehicle);
            return RedirectToAction("Vehicles");
        }
        //ViewModel with list & new entry
        [HttpGet]
        public ActionResult Makes()
        {
            MakeVM makeVM = new MakeVM
            {
                Make = new Make(),
                MakeList = repo.MakeFactory().RetrieveAll()
            };

            return View(makeVM);
        }

        [HttpPost]
        public ActionResult Makes(MakeVM makeVM)
        {
            makeVM.Make.DateCreated = DateTime.Today;
            repo.MakeFactory().Create(makeVM.Make);
            return RedirectToAction("Makes");
        }

        //ViewModel with list & new entry
        [HttpGet]
        public ActionResult Models()
        {
            ModelVM modelVM = new ModelVM
            {
                MakeModelList = new List<MakeModel>(),
                MakeList = repo.MakeFactory().RetrieveAll()
            };
            foreach (var item in repo.ModelFactory().RetrieveAll())
            {
                MakeModel makeModel = new MakeModel
                {
                    Make = repo.MakeFactory().RetrieveOne(item.MakeId),
                    Model = item
                };
                modelVM.MakeModelList.Add(makeModel);
            }
            return View(modelVM);
        }
        [HttpPost]
        public ActionResult Models(ModelVM modelVM)
        {
            modelVM.Model.DateCreated = DateTime.Today;
            //UserId
            repo.ModelFactory().Create(modelVM.Model);
            return RedirectToAction("Models");
        }

        //ViewModel with list & new entry
        [HttpGet]
        public ActionResult Specials()
        {
            SpecialVM specialVM = new SpecialVM();
            specialVM.SpecialList = repo.SpecialFactory().RetrieveAll();
            return View(specialVM);
        }
        [HttpPost]
        public ActionResult Specials(SpecialVM specialVM)
        {
            repo.SpecialFactory().Create(specialVM.Special);
            return RedirectToAction("Specials");
        }

        [HttpGet]
        public ActionResult DeleteSpecial(int id)
        {
            return View(repo.SpecialFactory().RetrieveOne(id));
        }

        [HttpPost]
        public ActionResult DeleteSpecial(Special special)
        {
            repo.SpecialFactory().Delete(special.SpecialId);
            return RedirectToAction("Specials");
        }

        public ActionResult Users()
        {

            return View();
        }
    }
}