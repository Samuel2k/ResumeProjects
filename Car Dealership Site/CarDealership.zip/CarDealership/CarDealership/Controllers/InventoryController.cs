﻿using CarDealership.Models.Classes;
using CarDealership.UI.Data;
using CarDealership.UI.Models.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace CarDealership.Controllers
{
    public class InventoryController : Controller
    {
        private static RepoFactory repo = new RepoFactory();
        //Done?
        [HttpGet]
        public ActionResult Details(int id)
        {
            VehicleVM vehicleVM = new VehicleVM();
            Vehicle vehicle = repo.VehicleFactory().RetrieveOne(id);
            vehicleVM.Purchased = true;
            foreach (var item in repo.PurchaseFactory().RetrieveAll())
            {
                if (item.VehicleId == id)
                {
                    vehicleVM.Purchased = true;
                }
            }
            vehicleVM.Vehicle = vehicle;
            vehicleVM.Model = repo.ModelFactory().RetrieveOne(vehicle.ModelId);
            vehicleVM.Make = repo.MakeFactory().RetrieveOne(repo.ModelFactory().RetrieveOne(vehicle.ModelId).MakeId);
            vehicleVM.Interior = repo.InteriorFactory().RetrieveOne(vehicle.InteriorId);
            vehicleVM.Color = repo.ColorFactory().RetrieveOne(vehicle.ColorId);
            vehicleVM.BodyStyle = repo.BodyStyleFactory().RetrieveOne(vehicle.BodyStyleId);
            return View();
        }
        public ActionResult New()
        {
            return View();
        }
        public ActionResult Used()
        {
            return View();
        }
    }
}