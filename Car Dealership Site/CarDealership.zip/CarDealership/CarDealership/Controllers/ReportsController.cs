﻿using CarDealership.Models.Classes.View_Model_Classes;
using CarDealership.UI.Data;
using CarDealership.UI.Models.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace CarDealership.Controllers
{
    public class ReportsController : Controller
    {
        private static RepoFactory repoFactory = new RepoFactory();
        //Complete Sales & Inventory with count
        public ActionResult Index()
        {
            return View();
        }
        [HttpGet]
        public ActionResult Sales()
        {
            //For each sale (purchase) that the user has successfully done, add to the count & add the price up
            throw new NotImplementedException();
        }

        [HttpGet]
        public ActionResult Inventory()
        {
            InventoryVM inventoryVM = new InventoryVM();

            int matchNumber = 0;
            foreach (var item in repoFactory.VehicleFactory().RetrieveAll())
            {
                CountVehicle countVehicle = new CountVehicle();
                
            }
            return View();
        }
    }
}